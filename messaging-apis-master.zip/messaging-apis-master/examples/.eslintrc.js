module.exports = {
  rules: {
    'import/no-unresolved': 'off',
    'no-console': 'off',
  },
};
