const server = require('./server');

server.listen(3000, () => {
  console.log(`Server is running on localhost:3000`);
});
