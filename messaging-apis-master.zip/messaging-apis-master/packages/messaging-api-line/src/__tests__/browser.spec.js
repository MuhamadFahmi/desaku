import { Line } from '../browser';

it('should export api correctly', () => {
  expect(Line).toBeDefined();
});
