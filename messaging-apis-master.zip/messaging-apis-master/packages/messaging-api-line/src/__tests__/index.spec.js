import { Line, LineClient } from '..';

it('should export api correctly', () => {
  expect(Line).toBeDefined();
  expect(LineClient).toBeDefined();
});
