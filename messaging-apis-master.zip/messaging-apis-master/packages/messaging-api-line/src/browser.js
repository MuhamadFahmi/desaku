/* @flow */

import Line from './Line';

export { Line };
export default { Line };
