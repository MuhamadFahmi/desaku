import { TelegramClient } from '..';

it('should export api correctly', () => {
  expect(TelegramClient).toBeDefined();
});
