/* @flow */

import TelegramClient from './TelegramClient';

export { TelegramClient };
export default { TelegramClient };
