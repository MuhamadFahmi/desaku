import { ViberClient } from '..';

it('should export api correctly', () => {
  expect(ViberClient).toBeDefined();
});
