/* @flow */

import ViberClient from './ViberClient';

export { ViberClient };
export default { ViberClient };
