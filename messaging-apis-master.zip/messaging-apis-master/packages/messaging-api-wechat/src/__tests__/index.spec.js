import { WechatClient } from '..';

it('should export api correctly', () => {
  expect(WechatClient).toBeDefined();
});
