/* @flow */

import WechatClient from './WechatClient';

export { WechatClient };
export default { WechatClient };
